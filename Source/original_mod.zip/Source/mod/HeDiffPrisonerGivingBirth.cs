using RimWorld;
using Verse;

namespace DarkIntentionsWoohoo
{
    public class HeDiffPrisonerGivingBirth : Hediff
    {
        public Faction Faction { get; set; }
    }
}