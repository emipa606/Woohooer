﻿namespace DarkIntentionsWoohoo.mod.settings
{
    static internal class WoohooSettingHelper
    {
        public static WoohooModSettings latest;
    }
}