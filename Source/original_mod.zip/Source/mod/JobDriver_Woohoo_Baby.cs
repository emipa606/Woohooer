﻿using Verse;

namespace DarkIntentionsWoohoo
{
    class JobDriver_Woohoo_Baby : JobDriver_Woohoo
    {
        public override bool isMakeBaby()
        {
       /* Log.Message("[woohoo] Wants a baby!", false); */
            return true;
        }
    }
}